def Predict(model, val):
    return model.predict(val)    