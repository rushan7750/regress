import numpy as np
def preprocess(inp):
    return np.array(inp)
